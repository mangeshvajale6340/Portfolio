document.getElementById('contact-form').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Thanks for your message! (Demo only)');
    this.reset();
  });
  